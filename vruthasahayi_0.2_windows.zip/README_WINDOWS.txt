Vrutha Sahayi 0.2 (Beta) Installation Instructions for Windows users:
-------------------------------------------------------------------------------------------------

System Requirements:
1. Windows 10

Installation Instructions:
1. There is no special installation requirements for Vrutha Sahayi. This runs as a stand-alone executable

Running Instructions:
1. Extract the contents of vruthasahayi_0.2_windows.zip into a folder.
2. Double-click on vruthasahayi.exe to bring up the application.